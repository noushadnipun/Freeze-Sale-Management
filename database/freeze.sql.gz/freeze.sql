-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 19, 2020 at 11:02 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `freeze`
--

-- --------------------------------------------------------

--
-- Table structure for table `distributors`
--

CREATE TABLE `distributors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `distributors`
--

INSERT INTO `distributors` (`id`, `name`, `mobile`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Shariatpur-2', '019', 'Test description', '2020-10-19 15:58:31', '2020-10-19 16:00:31'),
(2, 'Smart Enterprise', NULL, NULL, '2020-10-19 16:02:42', '2020-10-19 16:02:42'),
(3, 'Lily Traders', NULL, NULL, '2020-10-19 16:02:54', '2020-10-19 16:02:54'),
(4, 'Unicon - 1', NULL, NULL, '2020-10-19 16:03:25', '2020-10-19 16:03:25');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2020_10_12_201948_create_outlets_table', 1),
(4, '2020_10_12_222513_create_service_table', 2),
(7, '2020_10_15_172002_create_sales_table', 3),
(8, '2020_10_15_172936_create_sales_item_table', 3),
(9, '2020_10_19_211153_create_distributor_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `outlets`
--

CREATE TABLE `outlets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `distributor_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `outlets`
--

INSERT INTO `outlets` (`id`, `name`, `address`, `mobile`, `distributor_id`, `created_at`, `updated_at`) VALUES
(1, 'Islamic VIP Canteen', 'Indira Road, Farmgate', '01679102441', NULL, '2020-10-12 15:06:25', '2020-10-18 15:06:48'),
(5, 'Burger Point', 'Bhuter Goly, Kolabagan', '01733787037', NULL, '2020-10-12 15:58:04', '2020-10-12 15:58:04'),
(6, 'Maisha Hotel', 'Dolphin Goli, Kalabagan', '01818016823', '1', '2020-10-16 14:36:12', '2020-10-19 16:18:53'),
(7, 'Bismillah Gen Store', 'West Raja Bazar, Tejgoan', '01868244311', '1', '2020-10-16 16:14:10', '2020-10-19 16:16:10');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `outlet_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `call_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `call_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visi_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visi_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `db_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivery_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grand_total` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `paid_amount` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `outlet_id`, `call_no`, `call_date`, `visi_id`, `visi_size`, `db_name`, `delivery_date`, `grand_total`, `discount`, `paid_amount`, `created_at`, `updated_at`) VALUES
(1, '1', '32502', '23/08/20', '37628', '372', 'Shariotpur-2', '17/10/2020', '450.00', '0', '450', '2020-10-16 12:53:40', '2020-10-19 07:32:59'),
(2, '5', '32533', '24/08/2020', '33497', '372', 'Shariatpur-2', NULL, '440.00', '10', '440', '2020-10-16 13:13:00', '2020-10-19 09:08:36'),
(3, '6', '32590', '25/08/20', '16628', '400', 'Shariatpur-2', NULL, '4300.00', '0', '1520', '2020-10-16 14:38:39', '2020-10-19 07:33:29'),
(4, '7', '32595', '25/08/2020', '12719', '372', 'Shariatpur-2', NULL, '13260.00', '0', '13260', '2020-10-16 16:18:23', '2020-10-19 07:07:50'),
(5, '5', '123', '20/10/2020', '322', '345', '12', '21/10/2020', '1000.00', NULL, NULL, '2020-10-19 14:38:06', '2020-10-19 14:38:06');

-- --------------------------------------------------------

--
-- Table structure for table `sales_item`
--

CREATE TABLE `sales_item` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sales_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `service_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `service_qty` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sales_item`
--

INSERT INTO `sales_item` (`id`, `sales_id`, `service_id`, `service_qty`, `created_at`, `updated_at`) VALUES
(1, '1', '4', '1', NULL, '2020-10-19 07:32:59'),
(2, '2', '4', '1', NULL, '2020-10-19 09:08:36'),
(3, '3', '4', '2', '2020-10-16 20:38:39', '2020-10-19 07:33:29'),
(4, '3', '3', '3', '2020-10-16 20:38:39', '2020-10-19 07:33:29'),
(5, '3', '8', '2', '2020-10-16 20:38:39', '2020-10-19 07:33:29'),
(6, '4', '5', '1', '2020-10-16 22:18:23', '2020-10-19 07:07:50'),
(7, '4', '7', '6', '2020-10-16 22:18:23', '2020-10-19 07:07:50'),
(8, '4', '8', '1', '2020-10-16 22:18:23', '2020-10-19 07:07:50'),
(9, '4', '9', '1', '2020-10-16 22:18:23', '2020-10-19 07:07:50'),
(10, '4', '10', '1', '2020-10-16 22:18:23', '2020-10-19 07:07:50'),
(11, '4', '11', '3', '2020-10-16 22:18:23', '2020-10-19 07:07:50'),
(12, '4', '12', '1', '2020-10-16 22:18:23', '2020-10-19 07:07:50'),
(13, '4', '4', '1', '2020-10-16 22:18:23', '2020-10-19 07:07:50'),
(14, '5', '1', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `name`, `rate`, `created_at`, `updated_at`) VALUES
(1, '16 W Fan Motor', '1000', '2020-10-12 16:39:17', '2020-10-12 16:39:17'),
(2, '2 Pin Plug (Per Unit)', '70', '2020-10-12 16:39:50', '2020-10-12 16:39:50'),
(3, 'Axial Fan Motor', '1000', '2020-10-12 16:40:33', '2020-10-12 16:40:33'),
(4, 'Service Charge', '450', '2020-10-12 16:41:47', '2020-10-12 16:41:47'),
(5, 'Gas Charge', '10000', '2020-10-12 16:42:10', '2020-10-12 16:42:10'),
(6, '1/4 Coper Pipe (Per Fit)', '30', '2020-10-12 16:42:49', '2020-10-12 16:42:49'),
(7, 'Stainer', '70', '2020-10-12 16:43:30', '2020-10-12 16:43:30'),
(8, 'Compressor Oil', '200', '2020-10-12 16:43:53', '2020-10-12 16:43:53'),
(9, 'Denting', '800', '2020-10-12 16:44:07', '2020-10-12 16:44:07'),
(10, 'Jali 3/4 Fit', '450', '2020-10-12 16:44:35', '2020-10-12 16:44:35'),
(11, 'Painting (Per Feet)', '120', '2020-10-12 16:45:14', '2020-10-12 16:45:14'),
(12, 'Trans Charge', '580', '2020-10-12 16:45:32', '2020-10-12 16:45:32'),
(13, 'Axial Fan Motor', '1000', '2020-10-12 16:45:55', '2020-10-12 16:45:55');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Noushad Nipun', 'nipun@software.com', NULL, '$2y$10$yzgehL006QaLXhUM751nFuda5nKFjp2cQBieWUxhYGl/eZJbSw2Zy', 'f2XsJDHwnu24LEHs0FsfEzY1tMZ8bgvaOWPPUAoJOTrM6FLf6ut3cCoYHfVd', '2020-10-18 16:36:36', '2020-10-18 16:36:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `distributors`
--
ALTER TABLE `distributors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `outlets`
--
ALTER TABLE `outlets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales_item`
--
ALTER TABLE `sales_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `distributors`
--
ALTER TABLE `distributors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `outlets`
--
ALTER TABLE `outlets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sales_item`
--
ALTER TABLE `sales_item`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
